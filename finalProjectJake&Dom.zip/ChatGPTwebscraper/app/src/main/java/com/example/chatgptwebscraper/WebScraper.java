package com.example.chatgptwebscraper;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class WebScraper extends AsyncTask<Void, Void, String[]> {
    private final String TAG = "WebScraper";
    private String URL;
    private String tag;
    private TextView textView;
    private int num;

    public WebScraper(TextView textView, String url, String tag, int num) {
        this.textView = textView;
        this.URL=url;
        this.tag=tag;
        this.num=num;
    }

    @Override
    protected String[] doInBackground(Void... voids) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(URL)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String htmlContent = response.body().string();
                Document document = Jsoup.parse(htmlContent);
                Elements eventTitles = document.select(tag);
                String[] titles = new String[eventTitles.size()];
                for (int i = 0; i < eventTitles.size(); i++) {
                    Element titleElement = eventTitles.get(i);
                    titles[i] = titleElement.text();
                }
                String[] reduced={titles[num]};
                return reduced;
            } else {
                Log.e(TAG, "Unsuccessful response: " + response.code());
            }
        } catch (IOException e) {
            Log.e(TAG, "IOException: " + e.getMessage());
        }
        return null;
    }

    @Override
    protected void onPostExecute(String[] titles) {
        if (titles != null) {
            StringBuilder stringBuilder = new StringBuilder();
            for (String title : titles) {
                stringBuilder.append(title).append("\n");
            }
            textView.setText(stringBuilder.toString());
        } else {
            textView.setText("Failed to fetch event titles.");
        }
    }
}