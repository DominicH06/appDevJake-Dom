package com.example.chatgptwebscraper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView = findViewById(R.id.textView);
        TextView textView2=findViewById(R.id.textView2);
       // com.example.chatgptwebscraper.WebScraper webScraper = new com.example.chatgptwebscraper.WebScraper(textView, "https://www.horoscope.com/zodiac-signs/aries/friendship", "h3", 1);
        //webScraper.execute();
        ImageButton aries = (ImageButton) findViewById(R.id.ariesButton);
        aries.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
               WebScraper ariesWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=1", "p", 0);
               ariesWebScraper.execute();
               WebScraper ariesFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/aries/friendship", "h3", 1);
               ariesFriendCompat.execute();
            }
        });
        ImageButton taurus=(ImageButton)findViewById(R.id.taurusButton);
        taurus.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper taurusWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=2", "p",0);
                taurusWebScraper.execute();
                WebScraper taurusFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/taurus/friendship", "h3", 1);
                taurusFriendCompat.execute();
            }
        });
        ImageButton gemini=(ImageButton)findViewById(R.id.geminiButton);
        gemini.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper geminiWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=3", "p",0);
                geminiWebScraper.execute();
                WebScraper geminiFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/gemini/friendship", "h3", 1);
                geminiFriendCompat.execute();
            }
        });
        ImageButton cancer=(ImageButton)findViewById(R.id.cancerButton);
        cancer.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper cancerWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=4", "p",0);
                cancerWebScraper.execute();
                WebScraper cancerFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/cancer/friendship", "h3", 1);
                cancerFriendCompat.execute();
            }
        });
        ImageButton leo=(ImageButton)findViewById(R.id.leoButton);
        leo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper leoWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=5", "p",0);
                leoWebScraper.execute();
                WebScraper leoFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/leo/friendship", "h3", 1);
                leoFriendCompat.execute();
            }
        });
        ImageButton virgo=(ImageButton)findViewById(R.id.virgoButton);
        virgo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper virgoWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=6", "p",0);
                virgoWebScraper.execute();
                WebScraper virgoFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/virgo/friendship", "h3", 1);
                virgoFriendCompat.execute();
            }
        });
        ImageButton libra=(ImageButton)findViewById(R.id.libraButton);
        libra.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper libraWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=7", "p",0);
                libraWebScraper.execute();
                WebScraper libraFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/libra/friendship", "h3", 1);
                libraFriendCompat.execute();
            }
        });
        ImageButton scorpio=(ImageButton)findViewById(R.id.scorpioButton);
        scorpio.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper scorpioWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=8", "p",0);
                scorpioWebScraper.execute();
                WebScraper scorpioFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/scorpio/friendship", "h3", 1);
                scorpioFriendCompat.execute();
            }
        });
        ImageButton sagittarius=(ImageButton)findViewById(R.id.sagittariusButton);
        sagittarius.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper sagittariusWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=9", "p",0);
                sagittariusWebScraper.execute();
                WebScraper sagittariusFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/sagittarius/friendship", "h3", 1);
                sagittariusFriendCompat.execute();
            }
        });
        ImageButton capricorn=(ImageButton)findViewById(R.id.capricornButton);
        capricorn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper capricornWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=10", "p",0);
                capricornWebScraper.execute();
                WebScraper capricornFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/capricorn/friendship", "h3", 1);
                capricornFriendCompat.execute();
            }
        });
        ImageButton aquarius=(ImageButton)findViewById(R.id.aquariusButton);
        aquarius.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper aquariusWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=11", "p",0);
                aquariusWebScraper.execute();
                WebScraper aquariusFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/aquarius/friendship", "h3", 1);
                aquariusFriendCompat.execute();
            }
        });
        ImageButton pisces=(ImageButton)findViewById(R.id.piscesButton);
        pisces.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                WebScraper piscesWebScraper=new WebScraper(textView, "https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=12", "p",0);
                piscesWebScraper.execute();
                WebScraper piscesFriendCompat=new WebScraper(textView2, "https://www.horoscope.com/zodiac-signs/pisces/friendship", "h3", 1);
                piscesFriendCompat.execute();
            }
        });
    }
}