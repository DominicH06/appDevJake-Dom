package com.example.demo1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class myEventAdapter2(
    val eventList: List<Event1>,
    val context: AdapterView.OnItemSelectedListener
) : RecyclerView.Adapter<myEventAdapter2.MyEventViewHolder1>() {


    class MyEventViewHolder1(view : View) : RecyclerView.ViewHolder(view) {
        val eventImg : ImageView = view.findViewById(R.id.imageView1)
        val nameText : TextView = view.findViewById(R.id.nameText)
        val locText : TextView = view.findViewById(R.id.locationText)
        val eventDate : TextView = view.findViewById(R.id.date)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyEventViewHolder1 {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.eatery_cell, parent, false)
        return MyEventViewHolder1(view)
    }


    override fun onBindViewHolder(holder: MyEventViewHolder1, position: Int) {
        val event : Event1 = eventList[position]
        holder.nameText.text = event.eventName
        holder.locText.text = event.eventLocation
        holder.eventImg.setImageResource(event.eventImage)
        //holder.eventDate.text = ""+event.eventDate.get(2)+"/"+event.eventDate.get(5)+"/"+event.eventDate.get(1)
        //holder.eventDate.text = ""+event.eventDate.month+"/"+event.eventDate.date+"/"+event.eventDate.year
        holder.eventDate.text=""+event.eventDate.month+"/"+event.eventDate.date+"/"+event.eventDate.year
    }


    override fun getItemCount(): Int {
        return eventList.size
    }
}
