package com.example.demo1

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.ImageView

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val girlsButton : Button = findViewById(R.id.button)
        girlsButton.setOnClickListener {
            val aboutIntent = Intent(this, girlsActivity::class.java)

            startActivity(aboutIntent)
        }
        val boysButton : Button = findViewById(R.id.button2)
        boysButton.setOnClickListener {
            val aboutIntent = Intent(this, boysActivity::class.java)

            startActivity(aboutIntent)
        }

        val favButton : Button = findViewById(R.id.button6)
        favButton.setOnClickListener {
            val aboutIntent = Intent(this, favsActivity::class.java)
            startActivity(aboutIntent)
        }


        val calendarButton : Button = findViewById(R.id.button3)
        calendarButton.setOnClickListener {
            val aboutIntent = Intent(this, calendarActivity::class.java)
            startActivity(aboutIntent)
        }




        val form : Button = findViewById(R.id.button4)

        form.setOnClickListener{
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://forms.gle/RwAiZFdarnEf7MVPA"))
            startActivity(browserIntent)
        }






    }
}




