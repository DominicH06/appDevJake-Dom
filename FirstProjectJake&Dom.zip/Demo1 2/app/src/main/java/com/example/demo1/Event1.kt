package com.example.demo1

import java.util.Date


data class Event1 (
    var eventName : String,
    var eventDate : Date,
    var eventLocation : String,
    var eventImage : Int,
    var gender : String,
    var team : String
)

