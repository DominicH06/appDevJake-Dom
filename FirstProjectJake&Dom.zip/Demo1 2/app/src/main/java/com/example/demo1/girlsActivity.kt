package com.example.demo1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.time.ZonedDateTime
import java.util.Calendar
import java.util.Date


class girlsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_boys)

        var date1= Date(2024, 3, 15, 9, 2)
        val currentDate=Date()
        currentDate.month+=1
        currentDate.year=2024
        currentDate.hours=0
        currentDate.seconds=0
        //val date:Calendar=Calendar.getInstance()
        //date.set(2024, 3, 6, 1, 0)
        val eventList = listOf(
            //Event1(eventName="Softball (JV) v. Mira Mesa HS", eventDate=currentDate, eventLocation="Westview HS", eventImage=R.drawable.bruno),
            //Event1(eventName="lkasdfj;", eventDate=date1, eventLocation="Westview HS", eventImage=R.drawable.bruno)
            Event1(eventName="Badminton v. Canyon Crest Academy (League)", eventDate= Date(2024, 3, 19, 16, 30), eventLocation="Westview HS", eventImage=R.drawable.badminton, gender="Co-ed", team = "Badminton"),
            Event1(eventName="Track & Field {all levels} v. Torrey Pines", eventDate= Date(2024, 3, 21, 15, 45), eventLocation="Torrey Pines HS", eventImage=R.drawable.track, gender="Co-ed", team = "Track & Field"),
            Event1(eventName="Beach Volleyball Girls (V, JV) v. Rancho Bernardo", eventDate= Date(2024, 3, 21, 15, 45), eventLocation="Westview HS", eventImage=R.drawable.beach_volleyball, gender="Girls", team = "Beach Volleyball"),


            Event1(eventName="Volleyball Boys (V) LJHS Beach City Invitational", eventDate= Date(2024, 3, 22, 16, 0), eventLocation="La Jolla HS", eventImage=R.drawable.volleyball, gender="Boys", team = "Boys Volleyball"),
            Event1(eventName="Gymnastics v. Mt. Carmel HS", eventDate= Date(2024, 3, 22, 16, 30), eventLocation="Mt. Carmel HS", eventImage=R.drawable.gymnastics, gender="Girls", team = "Gymnastics"),
            Event1(eventName="Lacrosse Boys {JV, V} v. Francis Parker HS", eventDate= Date(2024, 3, 22, 17, 0), eventLocation="Westview HS", eventImage=R.drawable.lacrosse, gender="Boys", team = "Boys Lacrosse"),


            Event1(eventName="Track and Field MC Invite", eventDate= Date(2024, 3, 23, 8, 0), eventLocation="Mt. Carmel HS", eventImage=R.drawable.track, gender="Co-ed", team = "Track & Field"),
            Event1(eventName="Volleyball Boys (V) LJHS Beach City Invitational", eventDate= Date(2024, 3, 23, 10, 0), eventLocation="La Jolla HS", eventImage=R.drawable.volleyball, gender="Boys", team = "Boys Volleyball"),
            Event1(eventName="Baseball (F) v. Mt Carmel HS", eventDate= Date(2024, 3, 23, 10, 30), eventLocation="Mt. Carmel HS", eventImage=R.drawable.baseball, gender="Boys", team = "Baseball"),
            Event1(eventName="Baseball (F) v. NC Tourney (if qualify)", eventDate= Date(2024, 3, 23, 10, 30), eventLocation="Poway HS", eventImage=R.drawable.baseball, gender="Boys", team = "Baseball"),
            Event1(eventName="Baseball (JV) v. Mt Carmel HS", eventDate= Date(2024, 3, 23, 10, 30), eventLocation="Mt. Carmel HS", eventImage=R.drawable.baseball, gender="Boys", team = "Baseball"),
            Event1(eventName="Softball (V) v. Hilltop HS - {HST - Tournament Final]", eventDate= Date(2024, 3, 23, 12, 0), eventLocation="Hilltop HS", eventImage=R.drawable.softball, gender="Girls", team = "Softball"),


            Event1(eventName="Softball (JV) v. Mira Mesa HS", eventDate= Date(2024, 3, 25, 17, 30), eventLocation="Westview HS", eventImage=R.drawable.softball, gender="Girls", team = "Softball"),
            Event1(eventName="Beach Volleyball Girls (V, JV) v. Canyon Crest Academy", eventDate= Date(2024, 17, 25, 3, 45), eventLocation="Westview HS", eventImage=R.drawable.beach_volleyball, gender="Girls", team = "Beach Volleyball"),
            Event1(eventName="Baseball (V) v. Kennedy HS", eventDate= Date(2024, 3, 25, 16, 0), eventLocation="Westview HS", eventImage=R.drawable.baseball, gender="Boys", team = "Baseball"),


            Event1(eventName="Golf (Boys) v. Rancho Bernardo HS", eventDate= Date(2024, 3, 26, 17, 30), eventLocation="The Heights Golf Club", eventImage=R.drawable.golf, gender="Boys", team = "Boys Golf"),
            Event1(eventName="Softball v. Torrey Pines HS", eventDate= Date(2024, 3, 26, 17, 30), eventLocation="Westview HS", eventImage=R.drawable.softball, gender="Girls", team = "Softball"),
            Event1(eventName="Beach Volleyball Girls (V, JV) v. Mount Carmel", eventDate= Date(2024, 3, 26, 17, 45), eventLocation="Miramar College, j-100 Gymnasium", eventImage=R.drawable.beach_volleyball, gender="Girls", team = "Beach Volleyball"),
            Event1(eventName="Baseball (V) v. San Marcos HS", eventDate= Date(2024, 3, 26, 16, 0), eventLocation="San Marcos High School", eventImage=R.drawable.baseball, gender="Boys", team = "Baseball"),
            Event1(eventName="Lacrosse Boys (JV, V) v. Carlsbad HS", eventDate= Date(2024, 3, 26, 17, 30), eventLocation="Carlsbad HS", eventImage=R.drawable.lacrosse, gender="Boys", team = "Boys Lacrosse"),
            Event1(eventName="Lacrosse Girls (JV, V) v. Rancho Bernardo HS/El Camino HS", eventDate= Date(2024, 3, 26, 18, 0), eventLocation="Westview HS", eventImage=R.drawable.lacrosse, gender="Girls", team = "Girls Lacrosse"),
            Event1(eventName="Badminton v. Torrey Pines HS (League)", eventDate= Date(2024, 3, 26, 18, 30), eventLocation="Westview HS", eventImage=R.drawable.badminton, gender="Co-ed", team = "Badminton"),




            Event1(eventName="Tennis Boys (JV) v. Carlsbad HS", eventDate= Date(2024, 3, 27, 15, 30), eventLocation="Westview HS", eventImage=R.drawable.tennis, gender="Boys", team = "Boys Tennis"),
            Event1(eventName="Tennis Boys (V) v. Carlsbad HS", eventDate= Date(2024, 3, 27, 17, 30), eventLocation="Carlsbad HS", eventImage=R.drawable.tennis, gender="Boys", team = "Boys Tennis"),
            Event1(eventName="Baseball (V) v. Kennedy HS", eventDate= Date(2024, 3, 27, 16, 0), eventLocation="Westview HS", eventImage=R.drawable.baseball, gender="Boys", team = "Baseball"),
            Event1(eventName="Volleyball Boys v. Rancho Bernardo HS", eventDate= Date(2024, 3, 27, 16, 30), eventLocation="Westview HS", eventImage=R.drawable.volleyball, gender="Boys", team = "Boys Volleyball"),






            )


        var filteredList=ArrayList<Event1>()
        eventList.forEach{
                e->
            if(e.eventDate.compareTo(currentDate)>=0){
                filteredList.add(e)
            }
        }

        var girlsEvents=ArrayList<Event1>()
        filteredList.forEach{
                e->
            if(e.gender.equals("Girls")||e.gender.equals("Co-ed")){
                girlsEvents.add(e)
            }
        }
        val recyclerView : RecyclerView = findViewById(R.id.recycler)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = myEventAdapter(girlsEvents, this)


    }
}
