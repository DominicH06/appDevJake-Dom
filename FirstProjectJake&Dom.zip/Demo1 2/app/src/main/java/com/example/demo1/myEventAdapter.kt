package com.example.demo1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView


class myEventAdapter(
    val eventList : List<Event1>,
    val context : Context
) : RecyclerView.Adapter<myEventAdapter.MyEventViewHolder>() {


    class MyEventViewHolder(view : View) : RecyclerView.ViewHolder(view) {
        val eventImg : ImageView = view.findViewById(R.id.imageView1)
        val nameText : TextView = view.findViewById(R.id.nameText)
        val locText : TextView = view.findViewById(R.id.locationText)
        val eventDate : TextView = view.findViewById(R.id.date)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyEventViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.eatery_cell, parent, false)
        return MyEventViewHolder(view)
    }


    override fun onBindViewHolder(holder: MyEventViewHolder, position: Int) {
        val event : Event1 = eventList[position]
        holder.nameText.text = event.eventName
        holder.locText.text = event.eventLocation
        holder.eventImg.setImageResource(event.eventImage)
        //holder.eventDate.text = ""+event.eventDate.get(2)+"/"+event.eventDate.get(5)+"/"+event.eventDate.get(1)
        //holder.eventDate.text = ""+event.eventDate.month+"/"+event.eventDate.date+"/"+event.eventDate.year
        holder.eventDate.text=""+event.eventDate.month+"/"+event.eventDate.date+"/"+event.eventDate.year
    }


    override fun getItemCount(): Int {
        return eventList.size
    }
}
